#include <iostream>
#include <cstring>
#include <cstdlib>

// === ENCAPSULATION ===
// STUDENT-TODO: Implement SecureVault according to encapsulation principles
class SecureVault {
    int totalCapacity;
    int usedSpace;

public:
    SecureVault(int capacity) : totalCapacity(capacity), usedSpace(0) {}

    // TODO: Implement storage allocation logic
     
    bool storeItem(int size) {
        if (usedSpace + size > totalCapacity) {
            return false;
        } 
		else {
            usedSpace += size;
            return true;
        }
    }

    // TODO: Implement remaining space calculation
    int getRemainingSpace() const {
    	int Remain = totalCapacity - usedSpace;
        return Remain;
    }

    // TODO: Add anti-copy measures (delete copy constructor/assignment)
    //The third thing that is said to prevent copy 
    SecureVault(const SecureVault&) = delete;
    SecureVault& operator=(const SecureVault&) = delete;
    //(optional Also we can use getter)
    //int getUsedSpace() const { return usedSpace; }
    //int getTotalCapacity() const { return totalCapacity; }
};

// === ABSTRACTION ===
// STUDENT-TODO: Complete Artifact base class
class Artifact {
protected:
    char originCountry[40];
    int discoveryYear;

public:
    // TODO: Implement constructor with proper string handling
    Artifact(const char* country, int year) : discoveryYear(year) {
        // Copy country to originCountry with null termination
        strncpy(originCountry, country, 39);
        originCountry[39] = '\0';
    }

    virtual ~Artifact() {}
    // TODO: Declare pure virtual interface methods
    // describe() - output artifact details
    // storageNeeds() - calculate required space
    
    // HINT: Use = 0 to make methods pure virtual

    virtual void describe() const = 0;
    virtual int storageNeeds() const = 0;
};

// === INHERITANCE + POLYMORPHISM ===
// STUDENT-TODO: Implement Painting subclass
class Painting : public Artifact {
    char artistName[30];

public:
    // TODO: Implement constructor
    Painting(const char* artist, const char* country, int year)
        : Artifact(country, year) {
        // Copy artist name with null termination
        strncpy(artistName, artist, 29);
        artistName[29] = '\0';
    }
    // TODO: Override describe() and storageNeeds()
    void describe() const override {
        // Format: "Painting by [artist] ([year]), Origin: [country]"
        std::cout << "Painting by " << artistName << " (" << discoveryYear << "), Origin: " << originCountry << "\n";
    }

    int storageNeeds() const override {
        // Older than 100 years needs 300 units, else 150
        int age = 2025 - discoveryYear;
        if (age >= 100) {
            return 300;
        } 
		else {
            return 150;
        }
    }
};

// STUDENT-TODO: Implement Sculpture subclass
class Sculpture : public Artifact {
    char material[30];
    double weight;

public:
    // TODO: Implement constructor
    Sculpture(const char* mat, double w, const char* country, int year)
        : Artifact(country, year), weight(w) {
        // Copy material with null termination
        strncpy(material, mat, 29);
        material[29] = '\0';
    }
    // TODO: Override describe() and storageNeeds()
    void describe() const override {
        // Format: "[weight]kg [material] sculpture ([year]), From: [country]"
         std::cout << weight << "kg " << material << " sculpture (" << discoveryYear << "), From: " << originCountry << "\n";
    }

    int storageNeeds() const override {
        // 50 units per kg (cast to int)
        int result = weight * 50;
        return result;
    }
};

// === SYSTEM CORE === (PRE-IMPLEMENTED - DO NOT MODIFY)
class MuseumSystem {
    static const int MAX_ITEMS = 15;
    Artifact* collection[MAX_ITEMS];
    SecureVault vault;
    int itemCount;
    // Private constructor for singleton pattern
    MuseumSystem() : vault(5000), itemCount(0) {
        memset(collection, 0, sizeof(collection));
    }

public:
    static MuseumSystem& getInstance() {
        static MuseumSystem instance;
        return instance;
    }

    ~MuseumSystem() {
        for(int i = 0; i < itemCount; ++i) {
            delete collection[i];
        }
    }

    bool addArtifact(Artifact* item) {
        if(itemCount >= MAX_ITEMS) {
            return false;
        } else {
            int needed = item->storageNeeds();
            if(!vault.storeItem(needed)) {
                delete item;
                return false;
            } else {
                collection[itemCount++] = item;
                return true;
            }
        }
    }

    void preserveAll() const {
        for(int i = 0; i < itemCount; ++i) {
            std::cout << "Preserving: ";
            collection[i]->describe();
        }
    }

    void displaySpace() const {
        std::cout << "Vault space: " << vault.getRemainingSpace()
                  << "/5000 remaining\n";
    }
};

// === COMMAND PROCESSING === (PRE-IMPLEMENTED - DO NOT MODIFY)
void processCommand(const char* cmd) {
    char* token = strtok(const_cast<char*>(cmd), " ");
    
    if(!token) return;
    
    if(strcmp(token, "ingest") == 0) {
        char* type = strtok(nullptr, " ");
        char* param1 = strtok(nullptr, "\"");
        char* param2 = strtok(nullptr, "\"");
        
        if(!type || !param1 || !param2) {
            std::cerr << "Invalid command format!\n";
            return;
        }
        
        Artifact* newItem = nullptr;
        
        if(strcmp(type, "painting") == 0) {
            char* country = strtok(nullptr, "\"");
            char* yearStr = strtok(nullptr, " ");
            int year = yearStr ? atoi(yearStr) : 0;
            
            if(country && year > 0) {
                newItem = new Painting(param1, country, year);
            }
        }
        else if(strcmp(type, "sculpture") == 0) {
            // Similar parsing for sculpture
            double weight = atof(param2);
            char* country = strtok(nullptr, "\"");
            char* yearStr = strtok(nullptr, " ");
            int year = yearStr ? atoi(yearStr) : 0;

            if(country && weight > 0 && year > 0) {
                newItem = new Sculpture(param1, weight, country, year);
            }
        }
        
        if(newItem && MuseumSystem::getInstance().addArtifact(newItem)) {
            std::cout << "Artifact added!\n";
        } else {
            std::cerr << "Failed to add artifact\n";
            delete newItem;
        }
    }
    else if(strcmp(token, "preserve") == 0) {
        MuseumSystem::getInstance().preserveAll();
    }
    else if(strcmp(token, "ledger") == 0) {
        MuseumSystem::getInstance().displaySpace();
    }
};

// === MAIN === (PRE-IMPLEMENTED - DO NOT MODIFY)
int main() {
    char buffer[256];
    
    while(true) {
        std::cout << "Museum> ";
        std::cin.getline(buffer, 255);
        
        if(strcmp(buffer, "halt") == 0) break;
        
        processCommand(buffer);
    }
    
    return 0;
};
